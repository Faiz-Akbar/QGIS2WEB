var wms_layers = [];


        var lyr_OpenStreetMap_0 = new ol.layer.Tile({
            'title': 'OpenStreetMap',
            //'type': 'base',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
    attributions: ' ',
                url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_2021_1 = new ol.format.GeoJSON();
var features_2021_1 = format_2021_1.readFeatures(json_2021_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_2021_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_2021_1.addFeatures(features_2021_1);
var lyr_2021_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_2021_1, 
                style: style_2021_1,
                popuplayertitle: "2021",
                interactive: true,
    title: '2021<br />\
    <img src="styles/legend/2021_1_0.png" /> 0 - 74,8<br />\
    <img src="styles/legend/2021_1_1.png" /> 74,8 - 82,8<br />\
    <img src="styles/legend/2021_1_2.png" /> 82,8 - 89,2<br />\
    <img src="styles/legend/2021_1_3.png" /> 89,2 - 93,6<br />\
    <img src="styles/legend/2021_1_4.png" /> 93,6 - 100<br />'
        });
var format_2022_2 = new ol.format.GeoJSON();
var features_2022_2 = format_2022_2.readFeatures(json_2022_2, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_2022_2 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_2022_2.addFeatures(features_2022_2);
var lyr_2022_2 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_2022_2, 
                style: style_2022_2,
                popuplayertitle: "2022",
                interactive: true,
    title: '2022<br />\
    <img src="styles/legend/2022_2_0.png" /> 0 - 77,8<br />\
    <img src="styles/legend/2022_2_1.png" /> 77,8 - 85,8<br />\
    <img src="styles/legend/2022_2_2.png" /> 85,8 - 90,4<br />\
    <img src="styles/legend/2022_2_3.png" /> 90,4 - 93,6<br />\
    <img src="styles/legend/2022_2_4.png" /> 93,6 - 98<br />'
        });
var format_2023_3 = new ol.format.GeoJSON();
var features_2023_3 = format_2023_3.readFeatures(json_2023_3, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_2023_3 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_2023_3.addFeatures(features_2023_3);
var lyr_2023_3 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_2023_3, 
                style: style_2023_3,
                popuplayertitle: "2023",
                interactive: true,
    title: '2023<br />\
    <img src="styles/legend/2023_3_0.png" /> 0 - 78,8<br />\
    <img src="styles/legend/2023_3_1.png" /> 78,8 - 86,8<br />\
    <img src="styles/legend/2023_3_2.png" /> 86,8 - 90,4<br />\
    <img src="styles/legend/2023_3_3.png" /> 90,4 - 94<br />\
    <img src="styles/legend/2023_3_4.png" /> 94 - 99<br />'
        });

lyr_OpenStreetMap_0.setVisible(true);lyr_2021_1.setVisible(true);lyr_2022_2.setVisible(true);lyr_2023_3.setVisible(true);
var layersList = [lyr_OpenStreetMap_0,lyr_2021_1,lyr_2022_2,lyr_2023_3];
lyr_2021_1.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'WADMPR': 'WADMPR', '_JML_PSTA': '_JML_PSTA', '_NAMA_INST': '_NAMA_INST', });
lyr_2022_2.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'WADMPR': 'WADMPR', '_JML_PSTA': '_JML_PSTA', '_NAMA_INST': '_NAMA_INST', });
lyr_2023_3.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'WADMPR': 'WADMPR', '_JML_PSTA': '_JML_PSTA', '_NAMA_INST': '_NAMA_INST', });
lyr_2021_1.set('fieldImages', {'OBJECTID': 'TextEdit', 'WADMPR': 'TextEdit', '_JML_PSTA': 'TextEdit', '_NAMA_INST': 'TextEdit', });
lyr_2022_2.set('fieldImages', {'OBJECTID': 'TextEdit', 'WADMPR': 'TextEdit', '_JML_PSTA': 'TextEdit', '_NAMA_INST': 'TextEdit', });
lyr_2023_3.set('fieldImages', {'OBJECTID': 'TextEdit', 'WADMPR': 'TextEdit', '_JML_PSTA': 'TextEdit', '_NAMA_INST': 'TextEdit', });
lyr_2021_1.set('fieldLabels', {'OBJECTID': 'no label', 'WADMPR': 'no label', '_JML_PSTA': 'no label', '_NAMA_INST': 'no label', });
lyr_2022_2.set('fieldLabels', {'OBJECTID': 'no label', 'WADMPR': 'no label', '_JML_PSTA': 'no label', '_NAMA_INST': 'no label', });
lyr_2023_3.set('fieldLabels', {'OBJECTID': 'no label', 'WADMPR': 'no label', '_JML_PSTA': 'no label', '_NAMA_INST': 'no label', });
lyr_2023_3.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});